const Sector=()=>{
    return (
        <div>
        Sector
        </div>
    )
}

export default Sector