const Timeline=()=>{
    return (
        <div>
            profile
        </div>
    )
}

export default Timeline