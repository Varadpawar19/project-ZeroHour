const MapView=()=>{
    return (
        <div>
            Map
        </div>
    )
}

export default MapView