module.exports = {
  content: [
    "./src/**/*.{html,js,jsx,ts,tsx}", // Add this line
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
